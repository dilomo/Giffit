﻿#region Copyright

///////////////////////////////////////////////////////////////////////////////
//  File: BitmapDataBase.cs
///////////////////////////////////////////////////////////////////////////////
//  Copyright (C) KGy SOFT, 2005-2021 - All Rights Reserved
//
//  You should have received a copy of the LICENSE file at the top-level
//  directory of this distribution.
//
//  Please refer to the LICENSE file if you want to use this source code.
///////////////////////////////////////////////////////////////////////////////

#endregion

#region Usings

using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.CompilerServices;

#endregion

namespace KGySoft.Drawing.Imaging
{
    [DebuggerDisplay("{" + nameof(Width) + "}x{" + nameof(Height) + "} {KGySoft.Drawing." + nameof(PixelFormatExtensions) + "." + nameof(PixelFormatExtensions.ToBitsPerPixel) + "(" + nameof(PixelFormat) + ")}bpp")]
    internal abstract class BitmapDataBase : IBitmapDataInternal
    {
        #region Properties and Indexers

        #region Properties

        #region Public Properties

        public abstract int Height { get; }
        public abstract int Width { get; }
        public abstract PixelFormat PixelFormat { get; }
        public Color32 BackColor { get; protected set; }
        public byte AlphaThreshold { get; protected set; }
        public Palette? Palette { get; protected set; }
        public abstract int RowSize { get; }
        public virtual bool CanSetPalette => PixelFormat.IsIndexed() && Palette != null;
        public bool IsDisposed { get; private set; }

        #endregion

        #region Explicitly Implemented Interface Properties

        IReadableBitmapDataRow IReadableBitmapData.FirstRow => GetFirstRow();
        IWritableBitmapDataRow IWritableBitmapData.FirstRow => GetFirstRow();
        IReadWriteBitmapDataRow IReadWriteBitmapData.FirstRow => GetFirstRow();

        #endregion

        #endregion

        #region Indexers

        #region Public Indexers

        public IReadWriteBitmapDataRow this[int y]
        {
            [MethodImpl(MethodImpl.AggressiveInlining)]
            get
            {
                if (IsDisposed)
                    ThrowDisposed();
                if ((uint)y >= Height)
                    ThrowYOutOfRange();
                return DoGetRow(y);
            }
        }

        #endregion

        #region Explicitly Implemented Interface Indexers

        IReadableBitmapDataRow IReadableBitmapData.this[int y] => this[y];
        IWritableBitmapDataRow IWritableBitmapData.this[int y] => this[y];

        #endregion

        #endregion

        #endregion

        #region Methods

        #region Static Methods

        [MethodImpl(MethodImplOptions.NoInlining)]
        private static void ThrowDisposed() => throw new ObjectDisposedException(null, PublicResources.ObjectDisposed);

        [MethodImpl(MethodImplOptions.NoInlining)]
        private static void ThrowYOutOfRange()
        {
            // ReSharper disable once NotResolvedInText
            throw new ArgumentOutOfRangeException("y", PublicResources.ArgumentOutOfRange);
        }

        #endregion

        #region Instance Methods

        #region Public Methods

        [MethodImpl(MethodImpl.AggressiveInlining)]
        public Color GetPixel(int x, int y)
        {
            if (IsDisposed)
                ThrowDisposed();
            if ((uint)y >= Height)
                ThrowYOutOfRange();
            return DoGetRow(y).GetColor(x);
        }

        [MethodImpl(MethodImpl.AggressiveInlining)]
        public void SetPixel(int x, int y, Color color)
        {
            if (IsDisposed)
                ThrowDisposed();
            if ((uint)y >= Height)
                ThrowYOutOfRange();
            DoGetRow(y).SetColor(x, color);
        }

        public abstract IBitmapDataRowInternal DoGetRow(int y);

        public virtual bool TrySetPalette(Palette? palette)
        {
            if (palette == null || Palette == null || !PixelFormat.IsIndexed() || palette.Count < Palette.Count || palette.Count > 1 << PixelFormat.ToBitsPerPixel())
                return false;
            if (palette.BackColor == BackColor && palette.AlphaThreshold == AlphaThreshold)
                Palette = palette;
            else
                Palette = new Palette(palette, BackColor, AlphaThreshold);

            return true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        #region Protected Methods

        protected virtual void Dispose(bool disposing) => IsDisposed = true;

        #endregion

        #region Private Methods

        private IReadWriteBitmapDataRow GetFirstRow()
        {
            if (IsDisposed)
                ThrowDisposed();
            return DoGetRow(0);
        }

        #endregion

        #endregion

        #endregion
    }
}
